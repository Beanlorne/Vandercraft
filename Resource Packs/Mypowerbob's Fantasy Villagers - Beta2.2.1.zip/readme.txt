HOW TO USE:

Villagers must be named with a name tag to transform.
There are two types of names you can give them. Either you can name them just as the species, which means they will have a random skin color:
- Dwarf
- Gnome
- Elf
- Orc
- Goblin

Or you can seperate them by geographical origin by giving them names similar to how vanilla Minecraft differentiates between biome varations of certain mobs.
These three words are:
- Cold for pale races
- Temperate/Temparate for tanner races
- Warm for darker races
with a space between the region and species name of course.
FOR EXAMPLE:
If you specifically want a green orc you would name it Temperate Orc (You can also use 'Temparate' in case you regularly misspell it like I do)
A pale elf would be Cold Elf, a dark gnome would be Warm Gnome, etc...
The names are also, luckily, not case-sensitive!


Certain variations of each species have a higher chance to appear than other variations.
Dwarves are more likely to be young and bearded rather than old or shaven for example.

Wandering traders will spawn as a random species, they should have a near equal chance to be any texture.



Link back to main page:
https://www.curseforge.com/minecraft/texture-packs/mypowerbobs-fantasy-villagers

Follow me on BlueSky for updates on this project:
https://bsky.app/profile/mypowerbob.bsky.social


Shoutout Intermet179, who made a resource pack named "Villagers With Arms". Without this pack I would never have learnt how to give my villagers with arms, and even though this pack is no longer built upon Intermet179's pack, I'm still very grateful for it's existence.
which you can find here: https://www.planetminecraft.com/texture-pack/villagers-with-arms-optifine-required/ 
